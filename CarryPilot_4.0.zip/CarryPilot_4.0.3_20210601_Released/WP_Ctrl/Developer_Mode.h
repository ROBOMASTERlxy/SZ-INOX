#ifndef _DEVELOPER_MODE_
#define _DEVELOPER_MODE_

extern int8_t SDK1_Mode_Setup,SDK2_Mode_Setup;
extern int8_t SDK_last_cnt;
extern uint8_t SDK1_MODE_CHANGE_FLAG;
extern uint8_t SDK2_MODE_CHANGE_FLAG;

void Auto_Flight_Ctrl(uint8_t mode);
void SDK_OPENMV_CHANGE_MODE(uint8_t *omvflag,uint8_t mode,COM_SDK com);


#endif



