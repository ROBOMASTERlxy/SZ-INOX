#ifndef __RESERVED_IO_H__
#define __RESERVED_IO_H__



void Reserved_IO_Init(void);
void Reserved_IO_Test(void);


#endif

